# Qwen Day0 910B reuse dry-run comparison

Source workbook: `wings_control\docs\DAY0\qwen模型收编.xlsx` (`Sheet1`, 12 rows x 16 columns)
Model rows: 8 | standard scenarios: 11 | reuse scenarios: 4
Hardware input standard: minimal hardware_info.json with `device` and `hardware_family`; no `details` input.
Function Call parser expectation: `qwen3_coder` per adaptation decision, even where the source script text still says `hermes`.
Qwen MemCache expectation: AscendStoreConnector config must not contain `kv_load_failure_policy`.
Qwen 910B policy: only Qwen3.6 W8A8 and Qwen3.5-35B-A3B reuse MemCache; other 910B Qwen rows still suppress offload.
Parallelism policy: TP is derived from `device_count`; DP is not emitted and uses the vLLM default `1`.
MemCache memory policy: page memory is node total and is evenly divided by `device_count` before writing per-card DRAM.

| Scenario | Result | Source | Hardware | Active features | Failed checks | start_command.sh |
|---|---:|---|---|---|---|---|
| Qwen3.5-35B-A3B-910B-reuse | FAIL | row3 / 910B reuse of row3 910C optimized + MemCache | `Ascend910B_64G` | `offload,spec` | served_model_name: expected `"qwen35"` actual `"Qwen/Qwen3.5-35B-A3B"`<br>speculative_config: expected `{"method": "qwen3_5_mtp", "num_speculative_tokens": 1, "enforce_eager": true}` actual `{"method": "qwen3_5_mtp", "num_speculative_tokens": 5}` | `wings_control\docs\DAY0\dry_run\qwen_day0_910b_reuse_current\Qwen3.5-35B-A3B-910B-reuse\start_command.sh` |
| Qwen3.5-122B-A10B-910B-reuse | FAIL | row4 / 910B reuse of row4 910C optimized | `Ascend910B_64G` | `spec` | served_model_name: expected `"qwen35"` actual `"Qwen/Qwen3.5-122B-A10B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_910b_reuse_current\Qwen3.5-122B-A10B-910B-reuse\start_command.sh` |
| Qwen3.6-27B-910B-reuse | FAIL | row6 / 910B reuse of row6 910C optimized + dependency script | `Ascend910B_64G` | `spec` | served_model_name: expected `"qwen36"` actual `"Qwen/Qwen3.6-27B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_910b_reuse_current\Qwen3.6-27B-910B-reuse\start_command.sh` |
| Qwen3.6-35B-A3B-910B-reuse | FAIL | row8 / 910B reuse of row8 910C optimized + dependency script | `Ascend910B_64G` | `spec` | served_model_name: expected `"qwen36"` actual `"Qwen/Qwen3.6-35B-A3B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_910b_reuse_current\Qwen3.6-35B-A3B-910B-reuse\start_command.sh` |

## Checked Fields

`TP`, `DP`, `port`, `served_model_name`, max sequence/token limits, GPU memory utilization, seed, `tool_call_parser`, Function Call switch, MTP method/token/enforce_eager, EP, quantization, `additional_config`, `compilation_config`, `language_model_only`, sparse absence, MemCache ports, and absence of Qwen `kv_load_failure_policy`.

Overall result: FAIL
