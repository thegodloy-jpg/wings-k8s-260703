# Qwen Day0 current dry-run comparison

Source workbook: `wings_control\docs\DAY0\qwen模型收编.xlsx` (`Sheet1`, 12 rows x 16 columns)
Model rows: 8 | standard scenarios: 11 | reuse scenarios: 4
Hardware input standard: minimal hardware_info.json with `device` and `hardware_family`; no `details` input.
Function Call parser expectation: `qwen3_coder` per adaptation decision, even where the source script text still says `hermes`.
Qwen MemCache expectation: AscendStoreConnector config must not contain `kv_load_failure_policy`.
Qwen 910B policy: only Qwen3.6 W8A8 and Qwen3.5-35B-A3B reuse MemCache; other 910B Qwen rows still suppress offload.
Parallelism policy: TP is derived from `device_count`; DP is not emitted and uses the vLLM default `1`.
MemCache memory policy: page memory is node total and is evenly divided by `device_count` before writing per-card DRAM.

| Scenario | Result | Source | Hardware | Active features | Failed checks | start_command.sh |
|---|---:|---|---|---|---|---|
| Qwen3.5-27B-910C | FAIL | row2 / 910C optimized | `Ascend910C` | `offload,spec` | served_model_name: expected `"qwen35"` actual `"Qwen/Qwen3.5-27B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.5-27B-910C\start_command.sh` |
| Qwen3.5-27B-910B | FAIL | row2 / 910B optimized | `Ascend910B_64G` | `spec` | served_model_name: expected `"qwen35"` actual `"Qwen/Qwen3.5-27B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.5-27B-910B\start_command.sh` |
| Qwen3.5-35B-A3B-910C | FAIL | row3 / 910C optimized | `Ascend910C` | `offload,spec` | served_model_name: expected `"qwen35"` actual `"Qwen/Qwen3.5-35B-A3B"`<br>kv_transfer_config: expected `null` actual `{"kv_connector": "AscendStoreConnector", "kv_role": "kv_both", "kv_connector_extra_config": {"lookup_rpc_port": "0", "backend": "memcache"}}`<br>no_disable_hybrid_kv_cache_manager: expected `false` actual `true`<br>memcache_meta_present: expected `false` actual `true`<br>memcache_config_present: expected `false` actual `true`<br>memcache_meta_port: expected `null` actual `"present"`<br>memcache_config_port: expected `null` actual `"present"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.5-35B-A3B-910C\start_command.sh` |
| Qwen3.5-122B-A10B-910C | FAIL | row4 / 910C optimized | `Ascend910C` | `spec` | served_model_name: expected `"qwen35"` actual `"Qwen/Qwen3.5-122B-A10B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.5-122B-A10B-910C\start_command.sh` |
| Qwen3.5-397B-A17B-910C | FAIL | row5 / 910C optimized | `Ascend910C` | `spec` | max_num_seqs: expected `4` actual `128`<br>max_model_len: expected `16384` actual `4096`<br>gpu_memory_utilization: expected `0.92` actual `null`<br>seed: expected `1024` actual `null`<br>served_model_name: expected `"qwen35"` actual `"Qwen/Qwen3.5-397B-A17B"`<br>language_model_only: expected `true` actual `false`<br>additional_config: expected `{"enable_cpu_binding": false, "ascend_compilation_config": {"enable_npugraph_ex": true, "enable_static_kernel": false}, "multistream_overlap_shared_expert": false}` actual `{"enable_cpu_binding": true}` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.5-397B-A17B-910C\start_command.sh` |
| Qwen3.6-27B-910C | FAIL | row6 / 910C optimized + dependency script | `Ascend910C` | `offload,spec` | served_model_name: expected `"qwen36"` actual `"Qwen/Qwen3.6-27B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.6-27B-910C\start_command.sh` |
| Qwen3.6-27B-w8a8-910C | FAIL | row7 / 910C optimized + dependency script | `Ascend910C` | `offload,spec` | served_model_name: expected `"qwen36"` actual `"Eco-Tech/Qwen3.6-27B-w8a8"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.6-27B-w8a8-910C\start_command.sh` |
| Qwen3.6-27B-w8a8-910B | FAIL | row7 / 910B optimized + reused MemCache | `Ascend910B_64G` | `offload,spec` | served_model_name: expected `"qwen36"` actual `"Eco-Tech/Qwen3.6-27B-w8a8"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.6-27B-w8a8-910B\start_command.sh` |
| Qwen3.6-35B-A3B-910C | FAIL | row8 / 910C optimized + dependency script | `Ascend910C` | `offload,spec` | served_model_name: expected `"qwen36"` actual `"Qwen/Qwen3.6-35B-A3B"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.6-35B-A3B-910C\start_command.sh` |
| Qwen3.6-35B-A3B-w8a8-910C | FAIL | row9 / 910C optimized + dependency script | `Ascend910C` | `offload,spec` | served_model_name: expected `"qwen36"` actual `"Eco-Tech/Qwen3.6-35B-A3B-w8a8"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.6-35B-A3B-w8a8-910C\start_command.sh` |
| Qwen3.6-35B-A3B-w8a8-910B | FAIL | row9 / 910B optimized + reused MemCache | `Ascend910B_64G` | `offload,spec` | served_model_name: expected `"qwen36"` actual `"Eco-Tech/Qwen3.6-35B-A3B-w8a8"` | `wings_control\docs\DAY0\dry_run\qwen_day0_current\Qwen3.6-35B-A3B-w8a8-910B\start_command.sh` |

## Checked Fields

`TP`, `DP`, `port`, `served_model_name`, max sequence/token limits, GPU memory utilization, seed, `tool_call_parser`, Function Call switch, MTP method/token/enforce_eager, EP, quantization, `additional_config`, `compilation_config`, `language_model_only`, sparse absence, MemCache ports, and absence of Qwen `kv_load_failure_policy`.

Overall result: FAIL
