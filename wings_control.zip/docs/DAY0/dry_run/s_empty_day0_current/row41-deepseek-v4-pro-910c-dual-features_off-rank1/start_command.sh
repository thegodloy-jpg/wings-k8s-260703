#!/usr/bin/env bash
set -euo pipefail
mkdir -p /var/log/wings
rm -rf /var/log/wings/prometheus_multiproc
mkdir -p /var/log/wings/prometheus_multiproc
# --- wings: env echo helpers ---
wings_source_env_with_diff() {
    local script_path="$1"
    local label="${2:-$1}"
    if [ "$#" -ge 2 ]; then
        shift 2
    else
        shift 1
    fi
    if [ ! -f "$script_path" ]; then
        echo "[wings-env-source] WARN: $label not found: $script_path"
        return 0
    fi

    local before_file after_file
    before_file="$(mktemp)"
    after_file="$(mktemp)"
    env | sort > "$before_file" || true

    set +u
    # shellcheck disable=SC1090
    source "$script_path" "$@"
    local source_rc=$?
    set -u

    env | sort > "$after_file" || true
    comm -13 "$before_file" "$after_file" | sed "s|^|[wings-env-source] $label |" || true
    rm -f "$before_file" "$after_file"
    return "$source_rc"
}
# --- end wings env echo helpers ---
export PROMETHEUS_MULTIPROC_DIR=/var/log/wings/prometheus_multiproc
echo "[wings-env] export PROMETHEUS_MULTIPROC_DIR=${PROMETHEUS_MULTIPROC_DIR:-}"

# --- log_analyzer: Worker节点不运行分析器 ---
echo "[log_analyzer] Worker节点(node_rank > 0)，跳过分析器启动"
# 确保共享卷目录存在
mkdir -p /shared-volume

export PYTHONUNBUFFERED=1
echo "[wings-env] export PYTHONUNBUFFERED=${PYTHONUNBUFFERED:-}"
exec > >(tee -a /var/log/wings/engine-full.log | grep --line-buffered -vE '"GET\s+/(health|metrics)\s|\b(Prefill|Decode) batch\b' | tee -a /var/log/wings/engine.log) 2>&1
# Patch triton driver.py: Ascend NPU has no Triton backend, return dummy driver
python3 << 'TRITON_PATCH_EOF'
try:
    import triton.runtime, os
    drv_path = os.path.join(os.path.dirname(triton.runtime.__file__), 'driver.py')
    with open(drv_path) as f:
        src = f.read()
    if 'raise RuntimeError' in src and 'PATCHED_NPU' not in src:
        patch = '''
        # PATCHED_NPU: Ascend NPU has no Triton backend, provide dummy driver
        class _NpuDummyDrv:
            def get_current_target(self):
                import types; return types.SimpleNamespace(backend='npu', arch='Ascend910B', warp_size=0)
            def get_current_device(self): return 0
            def get_device_capability(self, *a): return (0, 0)
            def get_device_properties(self, device=0):
                try:
                    import torch_npu; n = torch_npu.npu.get_device_name(device); c = 20 if '910B' in str(n) else 30
                except Exception: c = 20
                return {'num_aicore': c, 'num_vectorcore': c}
            def __getattr__(self, name): return _NpuDummyDrv()
            def __call__(self, *a, **k): return self
            def __repr__(self): return '<NpuDummy>'
            def __int__(self): return 0
            def __bool__(self): return False
        return _NpuDummyDrv()'''
        src = src.replace(
            'raise RuntimeError(f"{len(active_drivers)} active drivers ({active_drivers}). There should only be one.")',
            patch.strip()
        )
        with open(drv_path, 'w') as f:
            f.write(src)
        print('[triton-patch] Patched', drv_path, 'for Ascend NPU')
    else:
        print('[triton-patch] Already patched or not needed')
except Exception as e:
    print(f'[triton-patch] Skip: {e}')
TRITON_PATCH_EOF
# --- wings: modelslim_config.py QuaRot compatibility patch ---
python3 << 'MODELSLIM_PATCH_EOF'
try:
    import importlib.util, pathlib
    spec = importlib.util.find_spec('vllm_ascend.quantization.modelslim_config')
    if spec and spec.origin:
        p = pathlib.Path(spec.origin)
        txt = p.read_text()
        old = 'self.quant_description[shard_prefix + ' + '"' + '.weight' + '"' + ']'
        new = 'self.quant_description.get(shard_prefix + ' + '"' + '.weight' + '"' + ')'
        if old in txt:
            p.write_text(txt.replace(old, new))
            print('[modelslim-patch] Patched modelslim_config.py: dict[] -> dict.get() for QuaRot compatibility')
        else:
            print('[modelslim-patch] Already patched or pattern not found')
    else:
        print('[modelslim-patch] modelslim_config module not found, skipping')
except Exception as e:
    print(f'[modelslim-patch] Skip: {e}')
MODELSLIM_PATCH_EOF
# --- end modelslim patch ---
ENGINE_START_EPOCH=$(date +%s)
export HCCL_OP_EXPANSION_MODE="AIV"
echo "[wings-env] export HCCL_OP_EXPANSION_MODE=${HCCL_OP_EXPANSION_MODE:-}"
export HCCL_IF_IP=${POD_IP:-${RANK_IP:-$(hostname -i | awk '{print $1}')}}
echo "[wings-env] export HCCL_IF_IP=${HCCL_IF_IP:-}"
export GLOO_SOCKET_IFNAME=eth0
echo "[wings-env] export GLOO_SOCKET_IFNAME=${GLOO_SOCKET_IFNAME:-}"
export TP_SOCKET_IFNAME=eth0
echo "[wings-env] export TP_SOCKET_IFNAME=${TP_SOCKET_IFNAME:-}"
export HCCL_SOCKET_IFNAME=eth0
echo "[wings-env] export HCCL_SOCKET_IFNAME=${HCCL_SOCKET_IFNAME:-}"
export HCCL_BUFFSIZE=2048
echo "[wings-env] export HCCL_BUFFSIZE=${HCCL_BUFFSIZE:-}"
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
echo "[wings-env] export PYTORCH_NPU_ALLOC_CONF=${PYTORCH_NPU_ALLOC_CONF:-}"
export OMP_PROC_BIND=false
echo "[wings-env] export OMP_PROC_BIND=${OMP_PROC_BIND:-}"
export OMP_NUM_THREADS=10
echo "[wings-env] export OMP_NUM_THREADS=${OMP_NUM_THREADS:-}"
export TASK_QUEUE_ENABLE=1
echo "[wings-env] export TASK_QUEUE_ENABLE=${TASK_QUEUE_ENABLE:-}"
export LD_PRELOAD=/usr/lib/aarch64-linux-gnu/libjemalloc.so.2:$LD_PRELOAD
echo "[wings-env] export LD_PRELOAD=${LD_PRELOAD:-}"
export VLLM_ASCEND_ENABLE_FLASHCOMM1=1
echo "[wings-env] export VLLM_ASCEND_ENABLE_FLASHCOMM1=${VLLM_ASCEND_ENABLE_FLASHCOMM1:-}"
echo '[wings-cmd] >>> exec vllm serve D:/project/wings-k8s-260703/wings_control/docs/DAY0/dry_run/s_empty_day0_current/_model_configs/row41-deepseek-v4-pro-910c-dual --max-model-len 135000 --max-num-batched-tokens 4096 --gpu-memory-utilization 0.9 --max-num-seqs 32 --enable-expert-parallel --quantization ascend --block-size 128 --async-scheduling --safetensors-load-strategy prefetch --compilation-config '"'"'{"cudagraph_mode":"FULL_DECODE_ONLY"}'"'"' --additional-config '"'"'{"enable_cpu_binding":true,"multistream_overlap_shared_expert":true,"ascend_compilation_config":{"enable_npugraph_ex":true,"enable_static_kernel":false}}'"'"' --tokenizer-mode deepseek_v4 --served-model-name dsv4 --default-chat-template-kwargs '"'"'{"thinking":false}'"'"' --tensor-parallel-size 16 --data-parallel-address 10.10.0.10 --data-parallel-rpc-port 13399 --data-parallel-size 2 --data-parallel-size-local 1 --headless --data-parallel-start-rank 1'
vllm serve D:/project/wings-k8s-260703/wings_control/docs/DAY0/dry_run/s_empty_day0_current/_model_configs/row41-deepseek-v4-pro-910c-dual --max-model-len 135000 --max-num-batched-tokens 4096 --gpu-memory-utilization 0.9 --max-num-seqs 32 --enable-expert-parallel --quantization ascend --block-size 128 --async-scheduling --safetensors-load-strategy prefetch --compilation-config '{"cudagraph_mode":"FULL_DECODE_ONLY"}' --additional-config '{"enable_cpu_binding":true,"multistream_overlap_shared_expert":true,"ascend_compilation_config":{"enable_npugraph_ex":true,"enable_static_kernel":false}}' --tokenizer-mode deepseek_v4 --served-model-name dsv4 --default-chat-template-kwargs '{"thinking":false}' --tensor-parallel-size 16 --data-parallel-address 10.10.0.10 --data-parallel-rpc-port 13399 --data-parallel-size 2 --data-parallel-size-local 1 --headless --data-parallel-start-rank 1 &
ENGINE_PID=$!
echo "[Engine] Engine PID: $ENGINE_PID"

# --- Engine process wait and exception handling (with crash retry) ---
echo "[Engine] Engine process monitor started, PID=$ENGINE_PID"
if wait "$ENGINE_PID"; then
  echo "[Engine] Engine process exited normally"
  echo "[引擎] 停止日志解析进程..."
  [ -n "${LOG_ANALYZER_PID:-}" ] && kill "$LOG_ANALYZER_PID" 2>/dev/null || true
  trap - EXIT
else
  EXIT_CODE=$?
  ENGINE_DURATION=$(( $(date +%s) - ENGINE_START_EPOCH ))
  echo "[Engine] Engine process exited abnormally, exit_code=$EXIT_CODE, runtime=${ENGINE_DURATION}s"
  echo "[Engine] ┌── Engine Crash Retry ──"
  echo "[Engine] │ Reason: Engine crashed (exit_code=$EXIT_CODE, runtime=${ENGINE_DURATION}s)"
  echo "[Engine] │ Action: Retrying engine startup with same parameters (attempt 2/2)"
  echo "[Engine] └── Retry command about to execute..."
  # 清理上一次启动残留：ray head/worker 进程 + 端口占用
  if command -v ray >/dev/null 2>&1; then
    echo "[Engine] Stopping leftover Ray cluster before retry..."
    echo '[wings-cmd] >>> ray stop --force >/dev/null 2>&1 || true'
    ray stop --force >/dev/null 2>&1 || true
  fi
  # 兜底：杀掉残留的 vLLM EngineCore / WorkerProc（父进程已死但子进程可能还在）
  pkill -9 -f 'vllm.*EngineCore' 2>/dev/null || true
  pkill -9 -f 'vllm.*WorkerProc' 2>/dev/null || true
  pkill -9 -f 'multiproc_executor' 2>/dev/null || true
  echo "[Engine] Waiting 5s for port release before retry..."
  sleep 5
  ENGINE_START_EPOCH=$(date +%s)
export HCCL_OP_EXPANSION_MODE="AIV"
echo "[wings-env] export HCCL_OP_EXPANSION_MODE=${HCCL_OP_EXPANSION_MODE:-}"
export HCCL_IF_IP=${POD_IP:-${RANK_IP:-$(hostname -i | awk '{print $1}')}}
echo "[wings-env] export HCCL_IF_IP=${HCCL_IF_IP:-}"
export GLOO_SOCKET_IFNAME=eth0
echo "[wings-env] export GLOO_SOCKET_IFNAME=${GLOO_SOCKET_IFNAME:-}"
export TP_SOCKET_IFNAME=eth0
echo "[wings-env] export TP_SOCKET_IFNAME=${TP_SOCKET_IFNAME:-}"
export HCCL_SOCKET_IFNAME=eth0
echo "[wings-env] export HCCL_SOCKET_IFNAME=${HCCL_SOCKET_IFNAME:-}"
export HCCL_BUFFSIZE=2048
echo "[wings-env] export HCCL_BUFFSIZE=${HCCL_BUFFSIZE:-}"
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
echo "[wings-env] export PYTORCH_NPU_ALLOC_CONF=${PYTORCH_NPU_ALLOC_CONF:-}"
export OMP_PROC_BIND=false
echo "[wings-env] export OMP_PROC_BIND=${OMP_PROC_BIND:-}"
export OMP_NUM_THREADS=10
echo "[wings-env] export OMP_NUM_THREADS=${OMP_NUM_THREADS:-}"
export TASK_QUEUE_ENABLE=1
echo "[wings-env] export TASK_QUEUE_ENABLE=${TASK_QUEUE_ENABLE:-}"
export LD_PRELOAD=/usr/lib/aarch64-linux-gnu/libjemalloc.so.2:$LD_PRELOAD
echo "[wings-env] export LD_PRELOAD=${LD_PRELOAD:-}"
export VLLM_ASCEND_ENABLE_FLASHCOMM1=1
echo "[wings-env] export VLLM_ASCEND_ENABLE_FLASHCOMM1=${VLLM_ASCEND_ENABLE_FLASHCOMM1:-}"
echo '[wings-cmd] >>> exec vllm serve D:/project/wings-k8s-260703/wings_control/docs/DAY0/dry_run/s_empty_day0_current/_model_configs/row41-deepseek-v4-pro-910c-dual --max-model-len 135000 --max-num-batched-tokens 4096 --gpu-memory-utilization 0.9 --max-num-seqs 32 --enable-expert-parallel --quantization ascend --block-size 128 --async-scheduling --safetensors-load-strategy prefetch --compilation-config '"'"'{"cudagraph_mode":"FULL_DECODE_ONLY"}'"'"' --additional-config '"'"'{"enable_cpu_binding":true,"multistream_overlap_shared_expert":true,"ascend_compilation_config":{"enable_npugraph_ex":true,"enable_static_kernel":false}}'"'"' --tokenizer-mode deepseek_v4 --served-model-name dsv4 --default-chat-template-kwargs '"'"'{"thinking":false}'"'"' --tensor-parallel-size 16 --data-parallel-address 10.10.0.10 --data-parallel-rpc-port 13399 --data-parallel-size 2 --data-parallel-size-local 1 --headless --data-parallel-start-rank 1'
vllm serve D:/project/wings-k8s-260703/wings_control/docs/DAY0/dry_run/s_empty_day0_current/_model_configs/row41-deepseek-v4-pro-910c-dual --max-model-len 135000 --max-num-batched-tokens 4096 --gpu-memory-utilization 0.9 --max-num-seqs 32 --enable-expert-parallel --quantization ascend --block-size 128 --async-scheduling --safetensors-load-strategy prefetch --compilation-config '{"cudagraph_mode":"FULL_DECODE_ONLY"}' --additional-config '{"enable_cpu_binding":true,"multistream_overlap_shared_expert":true,"ascend_compilation_config":{"enable_npugraph_ex":true,"enable_static_kernel":false}}' --tokenizer-mode deepseek_v4 --served-model-name dsv4 --default-chat-template-kwargs '{"thinking":false}' --tensor-parallel-size 16 --data-parallel-address 10.10.0.10 --data-parallel-rpc-port 13399 --data-parallel-size 2 --data-parallel-size-local 1 --headless --data-parallel-start-rank 1 &
ENGINE_PID=$!
echo "[Engine] Engine PID: $ENGINE_PID (retry mode)"
  echo "[Engine] Retry engine started, waiting for process exit..."
  if wait "$ENGINE_PID"; then
    echo "[Engine] Engine process exited normally (retry mode)"
      echo "[引擎] 停止日志解析进程..."
      [ -n "${LOG_ANALYZER_PID:-}" ] && kill "$LOG_ANALYZER_PID" 2>/dev/null || true
      trap - EXIT
  else
    EXIT_CODE=$?
    echo "[Engine] Retry also failed, exit_code=$EXIT_CODE — unrecoverable"

      CURR_TIME=$(date -Iseconds)
      SCRIPT_START_EPOCH="${SCRIPT_START_EPOCH:-$(date +%s)}"
      START_TIME=$(date -Iseconds -d "@${SCRIPT_START_EPOCH}")
      ELAPSED_TIME=$(( $(date +%s) - SCRIPT_START_EPOCH ))

      cat >> "/shared-volume/progress.jsonl" <<EOF
{"progress": 0, "phase_code": "engine_crash", "phase_name": "引擎进程异常退出", "status": "failed", "key_log": "引擎进程异常退出，退出码: $EXIT_CODE", "curr_time": "$CURR_TIME", "start_time": "$START_TIME", "elapsed_time_s": $ELAPSED_TIME}
EOF

      echo "[引擎] 停止日志解析进程..."
      [ -n "${LOG_ANALYZER_PID:-}" ] && kill "$LOG_ANALYZER_PID" 2>/dev/null || true
      trap - EXIT

    exit "$EXIT_CODE"
  fi
fi
